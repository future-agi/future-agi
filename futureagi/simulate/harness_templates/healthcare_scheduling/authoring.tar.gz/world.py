"""Generated world for healthcare_scheduling. Do not edit by hand; regenerate instead.

Initial logical baseline for healthcare_scheduling agent with patients, slots, red_flags, session_state, sub-goals and simulator prompt.
"""

from pathlib import Path

from fi.alk.harness.world.runtime import GeneratedWorld

_HERE = Path(__file__).parent

TOOLS = [
    {
        "name": "verify_patient",
        "description": "Verify the patient by name + date of birth. Required before reading or changing any record (PHI).",
        "parameters": {
            "name": {
                "type": "str",
                "values": null
            },
            "dob": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "check_availability",
        "description": "Find open appointment slots for a provider type within a date range.",
        "parameters": {
            "provider_type": {
                "type": "str",
                "values": null
            },
            "date_range": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "book_appointment",
        "description": "Book a specific slot for the verified patient with a reason for visit.",
        "parameters": {
            "slot_id": {
                "type": "str",
                "values": null
            },
            "reason": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "reschedule_appointment",
        "description": "Move an existing appointment to a new slot.",
        "parameters": {
            "appointment_id": {
                "type": "str",
                "values": null
            },
            "slot_id": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "cancel_appointment",
        "description": "Cancel an existing appointment.",
        "parameters": {
            "appointment_id": {
                "type": "str",
                "values": null
            },
            "reason": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "capture_insurance",
        "description": "Record the patient's insurance (payer, member ID, group).",
        "parameters": {
            "payer": {
                "type": "str",
                "values": null
            },
            "member_id": {
                "type": "str",
                "values": null
            },
            "group": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "send_intake_form_link",
        "description": "Send the digital intake/consent forms by SMS or email.",
        "parameters": {
            "channel": {
                "type": "str",
                "values": [
                    "sms",
                    "email"
                ]
            }
        }
    },
    {
        "name": "triage_check",
        "description": "Apply the fixed clinical rules table to the symptoms and return a band (emergency|urgent|routine).",
        "parameters": {
            "main_symptom": {
                "type": "str",
                "values": null
            },
            "severity": {
                "type": "str",
                "values": [
                    "mild",
                    "moderate",
                    "severe"
                ]
            },
            "duration": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "transfer_to_nurse",
        "description": "Warm-transfer to the nurse line with a summary of the reported symptoms.",
        "parameters": {
            "reason": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "advise_emergency",
        "description": "Red-flag symptom or emergency: tell the caller to call 911 / go to the ER now, then end safely.",
        "parameters": {}
    },
    {
        "name": "to_scheduling",
        "description": "Caller wants to book, reschedule, or cancel.",
        "parameters": {}
    },
    {
        "name": "to_intake",
        "description": "New patient, or needs to give/update insurance & details.",
        "parameters": {}
    },
    {
        "name": "to_triage",
        "description": "Caller is describing symptoms to decide whether/when to be seen.",
        "parameters": {}
    }
]


class World(GeneratedWorld):
    name = 'healthcare_scheduling'
    tools = TOOLS
    handlers = {
        name: (_HERE / "handlers" / f"{name}.py").read_text(encoding="utf-8")
        for name in []
    }


def load(database=None):
    """This world, restored from the snapshot beside this file.

    Through `restore` rather than by opening a database directly, because not every world has
    one: an agent whose state lives in services and files keeps its records in the snapshot, and
    naming a SQLite file would hand back an empty world instead of this one.
    """
    from fi.alk.harness.world.snapshot import restore

    return restore(_HERE, into=database) if database else restore(_HERE)
