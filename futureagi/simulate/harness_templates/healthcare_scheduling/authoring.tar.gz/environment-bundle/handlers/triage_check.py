from agent import TriageAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = TriageAgent()
    return settled(instance.triage_check(db.state, **args))
