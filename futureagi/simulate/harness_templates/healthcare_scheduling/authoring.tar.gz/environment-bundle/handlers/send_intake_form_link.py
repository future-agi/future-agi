from agent import IntakeAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = IntakeAgent()
    return settled(instance.send_intake_form_link(db.state, **args))
