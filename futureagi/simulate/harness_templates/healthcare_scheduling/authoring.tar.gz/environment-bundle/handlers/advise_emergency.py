from agent import BaseHealth
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = BaseHealth()
    return settled(instance.advise_emergency(db.state, **args))
