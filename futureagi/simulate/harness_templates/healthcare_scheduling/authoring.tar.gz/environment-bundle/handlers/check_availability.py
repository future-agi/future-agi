from agent import SchedulingAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = SchedulingAgent()
    return settled(instance.check_availability(db.state, **args))
