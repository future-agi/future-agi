from agent import FrontDeskAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = FrontDeskAgent()
    return settled(instance.verify_patient(db.state, **args))
