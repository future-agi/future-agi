def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Oliver Davies"), None)
    if not p:
        return "Patient Oliver Davies missing from world"
    return None