def setup(world):
    world.put("patients", {"patient_id": "PT-1009", "name": "Oliver Davies", "dob": "1979-02-18", "verified": True, "is_new_patient": False})