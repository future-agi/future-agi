def setup(world):
    world.put("patients", {"patient_id": "PT-1002", "name": "Claire Bennett", "dob": "1988-09-24", "verified": True, "is_new_patient": False})
    world.put("appointments", {"appointment_id": "APT-501", "patient_id": "PT-1002", "slot_id": "S-101", "reason": "Follow-up consultation", "status": "booked"})