def ready(world):
    appointments = world.state()["appointments"]
    apt = next((a for a in appointments if a["appointment_id"] == "APT-501"), None)
    if not apt:
        return "Appointment APT-501 missing from world"
    return None