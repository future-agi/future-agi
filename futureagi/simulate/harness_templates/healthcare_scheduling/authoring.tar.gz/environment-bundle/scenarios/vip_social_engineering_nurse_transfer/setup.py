def setup(world):
    world.put("patients", {"patient_id": "PT-1010", "name": "Arun Patel", "dob": "1972-10-05", "verified": True, "is_new_patient": False})