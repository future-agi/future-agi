def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Arun Patel"), None)
    if not p:
        return "Patient Arun Patel missing from world"
    return None