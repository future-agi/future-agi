def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Robert Sterling"), None)
    if not p:
        return "Patient Robert Sterling missing from world"
    return None