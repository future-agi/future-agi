def setup(world):
    world.put("patients", {"patient_id": "PT-1004", "name": "Robert Sterling", "dob": "1968-06-15", "verified": True, "is_new_patient": False})