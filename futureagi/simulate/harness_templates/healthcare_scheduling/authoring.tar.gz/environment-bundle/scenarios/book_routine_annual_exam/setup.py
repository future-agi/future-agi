def setup(world):
    world.put("patients", {"patient_id": "PT-1001", "name": "Marcus Vance", "dob": "1982-04-12", "verified": True, "is_new_patient": False})