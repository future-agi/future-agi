def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Marcus Vance"), None)
    if not p:
        return "Patient Marcus Vance missing from world"
    return None