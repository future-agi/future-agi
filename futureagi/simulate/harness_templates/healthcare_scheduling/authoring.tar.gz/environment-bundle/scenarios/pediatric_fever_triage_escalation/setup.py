def setup(world):
    world.put("patients", {"patient_id": "PT-1007", "name": "Fiona Campbell", "dob": "1986-07-22", "verified": True, "is_new_patient": False})