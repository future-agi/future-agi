def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Fiona Campbell"), None)
    if not p:
        return "Patient Fiona Campbell missing from world"
    return None