def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Rajesh Sharma"), None)
    if not p:
        return "Patient Rajesh Sharma missing from world"
    return None