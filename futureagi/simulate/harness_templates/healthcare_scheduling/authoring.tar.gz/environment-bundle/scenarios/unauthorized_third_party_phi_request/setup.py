def setup(world):
    world.put("patients", {"patient_id": "PT-1008", "name": "Rajesh Sharma", "dob": "1984-12-10", "verified": True, "is_new_patient": False})