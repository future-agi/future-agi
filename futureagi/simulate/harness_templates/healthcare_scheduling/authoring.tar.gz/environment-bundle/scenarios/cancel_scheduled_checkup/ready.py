def ready(world):
    appointments = world.state()["appointments"]
    apt = next((a for a in appointments if a["appointment_id"] == "APT-502"), None)
    if not apt:
        return "Appointment APT-502 missing from world"
    return None