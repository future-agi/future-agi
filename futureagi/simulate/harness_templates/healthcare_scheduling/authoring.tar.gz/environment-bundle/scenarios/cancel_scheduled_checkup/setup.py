def setup(world):
    world.put("patients", {"patient_id": "PT-1003", "name": "David Thorne", "dob": "1995-11-03", "verified": True, "is_new_patient": False})
    world.put("appointments", {"appointment_id": "APT-502", "patient_id": "PT-1003", "slot_id": "S-101", "reason": "General checkup", "status": "booked"})