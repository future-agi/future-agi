def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Amara Okafor"), None)
    if not p:
        return "Patient Amara Okafor missing from world"
    return None