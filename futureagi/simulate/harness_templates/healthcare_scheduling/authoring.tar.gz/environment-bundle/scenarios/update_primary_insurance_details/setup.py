def setup(world):
    world.put("patients", {"patient_id": "PT-1005", "name": "Amara Okafor", "dob": "1993-08-19", "verified": True, "is_new_patient": False})
    world.put("insurance", {"patient_id": "PT-1005", "payer": "Blue Cross Blue Shield", "member_id": "MEM-4910284", "group": "GRP-88210"})