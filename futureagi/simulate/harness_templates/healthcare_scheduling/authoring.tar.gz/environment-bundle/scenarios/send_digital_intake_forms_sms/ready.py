def ready(world):
    patients = world.state()["patients"]
    p = next((x for x in patients if x["name"] == "Liam Wright"), None)
    if not p:
        return "Patient Liam Wright missing from world"
    return None