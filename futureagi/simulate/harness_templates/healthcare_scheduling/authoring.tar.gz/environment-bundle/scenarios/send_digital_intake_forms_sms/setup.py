def setup(world):
    world.put("patients", {"patient_id": "PT-1006", "name": "Liam Wright", "dob": "2002-05-14", "verified": True, "is_new_patient": True})