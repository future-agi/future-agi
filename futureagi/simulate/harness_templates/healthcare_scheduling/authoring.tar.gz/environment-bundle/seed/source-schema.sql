CREATE TABLE IF NOT EXISTS harness_seed_sentinel (id text PRIMARY KEY);
INSERT INTO harness_seed_sentinel(id) VALUES ('ready') ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS _alk_tool_trace (id bigserial PRIMARY KEY, name text NOT NULL, arguments jsonb NOT NULL, result jsonb, ok boolean NOT NULL, error text, at double precision NOT NULL);
CREATE TABLE IF NOT EXISTS "appointments" ("appointment_id" text PRIMARY KEY, "patient_id" text, "slot_id" text, "reason" text, "status" text);
CREATE TABLE IF NOT EXISTS "insurance" ("patient_id" text, "payer" text, "member_id" text, "group" text);
CREATE TABLE IF NOT EXISTS "patients" ("patient_id" text PRIMARY KEY, "name" text NOT NULL, "dob" text NOT NULL, "verified" boolean NOT NULL, "is_new_patient" boolean NOT NULL);
CREATE TABLE IF NOT EXISTS "red_flags" ("flag" text PRIMARY KEY);
CREATE TABLE IF NOT EXISTS "session_state" ("patient_name" text, "is_new_patient" boolean, "verified" boolean, "patient_id" text, "appointment_id" text, "intent" text, "outcome" text);
CREATE TABLE IF NOT EXISTS "slots" ("slot_id" text PRIMARY KEY, "provider" text NOT NULL, "when" text NOT NULL, "location" text NOT NULL);
