from agent import FraudAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.FraudAgent()
    return settled(instance.file_dispute(db.state, **args))
