from agent import AuthenticateAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.AuthenticateAgent()
    return settled(instance.verify_identity(db.state, **args))
