from agent import BaseBank
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.BaseBank()
    return settled(instance.step_up_auth(db.state, **args))
