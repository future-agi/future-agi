from agent import CardServicesAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.CardServicesAgent()
    return settled(instance.lock_card(db.state, **args))
