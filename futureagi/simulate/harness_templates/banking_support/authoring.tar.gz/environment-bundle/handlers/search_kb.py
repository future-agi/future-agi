from agent import FaqAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.FaqAgent()
    return settled(instance.search_kb(db.state, **args))
