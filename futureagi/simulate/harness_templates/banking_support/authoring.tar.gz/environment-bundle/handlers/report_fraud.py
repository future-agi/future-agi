from agent import FraudAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.FraudAgent()
    return settled(instance.report_fraud(db.state, **args))
