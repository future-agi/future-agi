from agent import AccountInfoAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = agent.AccountInfoAgent()
    return settled(instance.get_balance(db.state, **args))
