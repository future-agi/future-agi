def ready(world):
    kb = world.state().get('kb_articles', [])
    records = list(kb.values()) if isinstance(kb, dict) else kb
    if not any('travel notice' in k.get('query', '') for k in records):
        return 'KB travel notice missing'
    return None