def ready(world):
    cust = world.state().get('customer', [])
    records = list(cust.values()) if isinstance(cust, dict) else cust
    if not any(c.get('customer_id') == 'CUS-6602' for c in records):
        return 'Customer CUS-6602 missing'
    return None