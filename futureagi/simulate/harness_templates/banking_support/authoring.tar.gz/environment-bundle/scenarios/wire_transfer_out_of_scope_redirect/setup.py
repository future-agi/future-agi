def setup(world):
    world.drop('customer', 'CUS-4410', by='customer_id')
    world.put('customer', {'customer_id': 'CUS-6602', 'customer_name': 'Priya Sharma', 'auth_level': None, 'step_up_verified': False})