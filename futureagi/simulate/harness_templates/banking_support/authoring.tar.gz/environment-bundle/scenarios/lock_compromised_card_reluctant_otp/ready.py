def ready(world):
    cards = world.state().get('cards', [])
    records = list(cards.values()) if isinstance(cards, dict) else cards
    if not any(c.get('card_last4') == '8812' for c in records):
        return 'Card 8812 not found'
    return None