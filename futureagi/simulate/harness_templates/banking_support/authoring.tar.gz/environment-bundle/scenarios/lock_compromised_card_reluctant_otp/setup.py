def setup(world):
    world.drop('customer', 'CUS-4410', by='customer_id')
    world.put('customer', {'customer_id': 'CUS-3190', 'customer_name': 'David Chen', 'auth_level': None, 'step_up_verified': False})
    world.drop('cards', '4410', by='card_last4')
    world.put('cards', {'card_last4': '8812', 'locked': False})