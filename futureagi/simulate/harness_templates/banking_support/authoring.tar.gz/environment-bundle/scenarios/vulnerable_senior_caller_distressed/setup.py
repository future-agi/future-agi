def setup(world):
    world.drop('customer', 'CUS-4410', by='customer_id')
    world.put('customer', {'customer_id': 'CUS-4105', 'customer_name': 'Arthur Henderson', 'auth_level': None, 'step_up_verified': False})
    world.drop('cards', '4410', by='card_last4')
    world.put('cards', {'card_last4': '1942', 'locked': False})