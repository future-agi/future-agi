def ready(world):
    cust = world.state().get('customer', [])
    records = list(cust.values()) if isinstance(cust, dict) else cust
    if not any(c.get('customer_id') == 'CUS-4105' for c in records):
        return 'Customer CUS-4105 missing'
    return None