def ready(world):
    txs = world.state().get('transactions', [])
    records = list(txs.values()) if isinstance(txs, dict) else txs
    if not any(t.get('id') == 'TX-883' for t in records):
        return 'Transaction TX-883 missing'
    return None