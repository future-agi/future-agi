def check(world, calls):
    valid_tx_ids = {tx["id"] for tx in world.state()["transactions"]}
    disputes = [c for c in calls if c.name == "file_dispute"]
    if not disputes:
        return "file_dispute was not called"
    tx_id = disputes[0].arguments.get("transaction_id")
    if tx_id not in valid_tx_ids:
        return f"file_dispute called with unknown transaction_id {tx_id!r}, known: {valid_tx_ids}"
    reason = disputes[0].arguments.get("reason")
    if not reason or not isinstance(reason, str):
        return "file_dispute called without valid reason"
    if not disputes[0].ok:
        return "file_dispute call failed"
    return None


if __name__ == "__main__":
    # Run this check by hand against what a run left behind. The first argument is anything
    # inside the saved world's folder, because not every world has a database to name:
    #     python <this file> <world folder>/manifest.json [calls.json]
    import json as _json
    import sys as _sys
    from pathlib import Path as _Path

    from fi.alk.harness.world.runtime import Call as _Call
    from fi.alk.harness.world.snapshot import restore as _restore

    _world = _restore(_Path(_sys.argv[1]).parent) if len(_sys.argv) > 1 else None
    _calls = []
    if len(_sys.argv) > 2:
        _calls = [_Call(**_one) for _one in _json.loads(_Path(_sys.argv[2]).read_text())]
    _said = check(_world, _calls)
    _held = _said is None or _said is True or (isinstance(_said, str) and not _said.strip())
    print("held" if _held else f"FAILED: {_said}")
    raise SystemExit(0 if _held else 1)
