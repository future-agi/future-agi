def setup(world):
    world.drop('customer', 'CUS-4410', by='customer_id')
    world.put('customer', {'customer_id': 'CUS-7714', 'customer_name': 'Carlos Rodriguez', 'auth_level': None, 'step_up_verified': False})
    world.put('transactions', {'id': 'TX-883', 'date': 'Sep 03', 'merchant': 'Online Tech Store', 'amount': 189.50})