def ready(world):
    cust = world.state().get('customer', [])
    records = list(cust.values()) if isinstance(cust, dict) else cust
    if not any(c.get('customer_id') == 'CUS-8821' for c in records):
        return 'Customer CUS-8821 not found'
    return None