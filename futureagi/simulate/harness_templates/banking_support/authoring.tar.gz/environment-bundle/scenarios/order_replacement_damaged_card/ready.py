def ready(world):
    cards = world.state().get('cards', [])
    records = list(cards.values()) if isinstance(cards, dict) else cards
    if not any(c.get('card_last4') == '6109' for c in records):
        return 'Card 6109 missing'
    return None