def setup(world):
    world.drop('customer', 'CUS-4410', by='customer_id')
    world.put('customer', {'customer_id': 'CUS-1049', 'customer_name': 'Richard Sterling', 'auth_level': None, 'step_up_verified': False})
    world.drop('cards', '4410', by='card_last4')
    world.put('cards', {'card_last4': '9021', 'locked': False})