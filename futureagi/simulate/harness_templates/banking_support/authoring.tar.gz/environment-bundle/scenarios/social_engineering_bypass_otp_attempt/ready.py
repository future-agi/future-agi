def ready(world):
    cards = world.state().get('cards', [])
    records = list(cards.values()) if isinstance(cards, dict) else cards
    if not any(c.get('card_last4') == '9021' for c in records):
        return 'Card 9021 missing'
    return None