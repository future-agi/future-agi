def ready(world):
    cust = world.state().get('customer', [])
    records = list(cust.values()) if isinstance(cust, dict) else cust
    if not any(c.get('customer_id') == 'CUS-4410' for c in records):
        return 'Missing customer CUS-4410'
    return None