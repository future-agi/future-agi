"""Generated world for banking_support. Do not edit by hand; regenerate instead.

Logical baseline for banking_support: schema and seeded data for accounts, cards, customer, transactions, disputes, fraud_cases, and kb_articles, voice simulator prompt, 13 sub-goals (9 coded, 4 judged), and 5 world checks.
"""

from pathlib import Path

from fi.alk.harness.world.runtime import GeneratedWorld

_HERE = Path(__file__).parent

TOOLS = [
    {
        "name": "verify_identity",
        "description": "Baseline identity verification. Required before any account interaction.",
        "parameters": {
            "identifier": {
                "type": "str",
                "values": null
            },
            "answer": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "to_account_info",
        "description": "Caller wants balance or recent transactions.",
        "parameters": {}
    },
    {
        "name": "to_card_services",
        "description": "Caller wants to lock, freeze, or replace a card.",
        "parameters": {}
    },
    {
        "name": "to_fraud",
        "description": "Caller wants to dispute a charge or report fraud/lost card.",
        "parameters": {}
    },
    {
        "name": "to_faq",
        "description": "Caller asks a general how-to question.",
        "parameters": {}
    },
    {
        "name": "step_up_auth",
        "description": "Send a one-time passcode to the customer's verified device. Required before sensitive actions.",
        "parameters": {}
    },
    {
        "name": "verify_otp",
        "description": "Verify the one-time passcode. Sets step-up auth on success.",
        "parameters": {
            "code": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "get_balance",
        "description": "Return current account balance(s). Allowed at baseline auth.",
        "parameters": {}
    },
    {
        "name": "get_transactions",
        "description": "Return recent transactions. Requires step-up auth.",
        "parameters": {
            "count": {
                "type": "int",
                "values": null
            }
        }
    },
    {
        "name": "lock_card",
        "description": "Lock/freeze a card by its last 4 digits. Requires step-up auth.",
        "parameters": {
            "card_last4": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "order_replacement_card",
        "description": "Order a replacement card. Requires step-up auth.",
        "parameters": {
            "card_last4": {
                "type": "str",
                "values": null
            },
            "reason": {
                "type": "str",
                "values": [
                    "lost",
                    "stolen",
                    "damaged"
                ]
            }
        }
    },
    {
        "name": "file_dispute",
        "description": "File a dispute for a specific transaction. Requires step-up auth.",
        "parameters": {
            "transaction_id": {
                "type": "str",
                "values": null
            },
            "reason": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "report_fraud",
        "description": "Report fraud or a lost/stolen card: locks the affected card and escalates to the fraud team.",
        "parameters": {
            "detail": {
                "type": "str",
                "values": null
            },
            "card_last4": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "search_kb",
        "description": "Answer a general how-to/policy question from the KB with citations. Never financial advice.",
        "parameters": {
            "query": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "escalate_to_human",
        "description": "Warm-transfer to a human banker with a summary of the interaction.",
        "parameters": {
            "reason": {
                "type": "str",
                "values": null
            }
        }
    }
]


class World(GeneratedWorld):
    name = 'banking_support'
    tools = TOOLS
    handlers = {
        name: (_HERE / "handlers" / f"{name}.py").read_text(encoding="utf-8")
        for name in []
    }


def load(database=None):
    """This world, restored from the snapshot beside this file.

    Through `restore` rather than by opening a database directly, because not every world has
    one: an agent whose state lives in services and files keeps its records in the snapshot, and
    naming a SQLite file would hand back an empty world instead of this one.
    """
    from fi.alk.harness.world.snapshot import restore

    return restore(_HERE, into=database) if database else restore(_HERE)
