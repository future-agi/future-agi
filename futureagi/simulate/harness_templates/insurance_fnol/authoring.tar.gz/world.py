"""Generated world for insurance_fnol. Do not edit by hand; regenerate instead.

Logical baseline for insurance_fnol inbound voice agent with seeded claims, policyholders, and knowledge base, conversational simulator prompt, 3 world checks, and 11 sub-goals (8 coded, 3 judged).
"""

from pathlib import Path

from fi.alk.harness.world.runtime import GeneratedWorld

_HERE = Path(__file__).parent

TOOLS = [
    {
        "name": "verify_policyholder",
        "description": "Verify the caller against the policy by matching ONE factor (dob | zip | last4_ssn).",
        "parameters": {
            "policy_number": {
                "type": "str",
                "values": null
            },
            "answer": {
                "type": "str",
                "values": null
            },
            "factor": {
                "type": "str",
                "values": [
                    "dob",
                    "zip",
                    "last4_ssn"
                ]
            }
        }
    },
    {
        "name": "to_fnol",
        "description": "Caller is reporting a new loss/incident.",
        "parameters": {}
    },
    {
        "name": "to_claim_status",
        "description": "Caller asks about an existing claim.",
        "parameters": {}
    },
    {
        "name": "to_policy_qa",
        "description": "Caller asks a general policy question.",
        "parameters": {}
    },
    {
        "name": "create_fnol",
        "description": "Create a First Notice of Loss and return a claim number.",
        "parameters": {
            "loss_datetime": {
                "type": "str",
                "values": null
            },
            "location": {
                "type": "str",
                "values": null
            },
            "loss_type": {
                "type": "str",
                "values": [
                    "auto",
                    "property",
                    "other"
                ]
            },
            "description": {
                "type": "str",
                "values": null
            },
            "injuries": {
                "type": "bool",
                "values": null
            },
            "other_parties": {
                "type": "str",
                "values": null
            },
            "police_report": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "send_document_upload_link",
        "description": "Send a secure link for photos/documents.",
        "parameters": {
            "channel": {
                "type": "str",
                "values": [
                    "sms",
                    "email"
                ]
            }
        }
    },
    {
        "name": "get_claim_status",
        "description": "Look up an existing claim's status, adjuster, and next step.",
        "parameters": {
            "claim_id": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "send_claim_confirmation",
        "description": "Send the claim details/status summary by SMS or email.",
        "parameters": {
            "channel": {
                "type": "str",
                "values": [
                    "sms",
                    "email"
                ]
            }
        }
    },
    {
        "name": "search_policy_kb",
        "description": "Answer a general policy/process question from the KB with citations. Never a coverage determination.",
        "parameters": {
            "query": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "schedule_adjuster_callback",
        "description": "Schedule a callback from a licensed adjuster, then end.",
        "parameters": {
            "when": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "advise_emergency",
        "description": "Active emergency / injury / hazard: tell the caller to contact 911 now, then end safely.",
        "parameters": {}
    },
    {
        "name": "escalate_to_licensed_agent",
        "description": "Warm-transfer to a licensed insurance rep. Use for any coverage determination, quote, advice, dispute, or human request.",
        "parameters": {
            "reason": {
                "type": "str",
                "values": null
            }
        }
    }
]


class World(GeneratedWorld):
    name = 'insurance_fnol'
    tools = TOOLS
    handlers = {
        name: (_HERE / "handlers" / f"{name}.py").read_text(encoding="utf-8")
        for name in []
    }


def load(database=None):
    """This world, restored from the snapshot beside this file.

    Through `restore` rather than by opening a database directly, because not every world has
    one: an agent whose state lives in services and files keeps its records in the snapshot, and
    naming a SQLite file would hand back an empty world instead of this one.
    """
    from fi.alk.harness.world.snapshot import restore

    return restore(_HERE, into=database) if database else restore(_HERE)
