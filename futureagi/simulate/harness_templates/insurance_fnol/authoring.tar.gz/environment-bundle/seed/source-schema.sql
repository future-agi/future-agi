CREATE TABLE IF NOT EXISTS harness_seed_sentinel (id text PRIMARY KEY);
INSERT INTO harness_seed_sentinel(id) VALUES ('ready') ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS _alk_tool_trace (id bigserial PRIMARY KEY, name text NOT NULL, arguments jsonb NOT NULL, result jsonb, ok boolean NOT NULL, error text, at double precision NOT NULL);
CREATE TABLE IF NOT EXISTS "claims" ("claim_id" text PRIMARY KEY, "status" text NOT NULL, "adjuster" text NOT NULL, "next_steps" text NOT NULL);
CREATE TABLE IF NOT EXISTS "knowledge_base" ("query" text PRIMARY KEY, "answer" text NOT NULL, "citations" jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS "policyholders" ("policy_number" text PRIMARY KEY, "name" text NOT NULL, "verified_factors" jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS "session_state" ("policy_number" text, "outcome" text, "verified" boolean, "loss_fields" jsonb, "claim_id" text, "intent" text, "agents" jsonb, "policyholder_name" text);
