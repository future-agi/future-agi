from agent import ClaimStatusAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = ClaimStatusAgent()
    return settled(instance.get_claim_status(db.state, **args))
