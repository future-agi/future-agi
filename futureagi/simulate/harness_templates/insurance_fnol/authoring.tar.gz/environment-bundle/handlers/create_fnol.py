from agent import FnolAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = FnolAgent()
    return settled(instance.create_fnol(db.state, **args))
