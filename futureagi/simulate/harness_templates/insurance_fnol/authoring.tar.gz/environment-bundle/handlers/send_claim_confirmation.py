from agent import ClaimStatusAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = ClaimStatusAgent()
    return settled(instance.send_claim_confirmation(db.state, **args))
