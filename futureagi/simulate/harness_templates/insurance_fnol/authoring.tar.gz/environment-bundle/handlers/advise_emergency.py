from agent import BaseInsurance
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = BaseInsurance()
    return settled(instance.advise_emergency(db.state, **args))
