from agent import FnolAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = FnolAgent()
    return settled(instance.send_document_upload_link(db.state, **args))
