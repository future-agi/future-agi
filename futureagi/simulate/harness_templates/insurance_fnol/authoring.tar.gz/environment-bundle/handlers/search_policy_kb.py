from agent import PolicyQaAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = PolicyQaAgent()
    return settled(instance.search_policy_kb(db.state, **args))
