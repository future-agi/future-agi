from agent import IdentifyAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = IdentifyAgent()
    return settled(instance.to_claim_status(db.state, **args))
