"""Generated world for debt_collection. Do not edit by hand; regenerate instead.

Deterministic baseline for outbound voice debt collection agent debt_collection with Jordan Lee account and standard installment plan options.
"""

from pathlib import Path

from fi.alk.harness.world.runtime import GeneratedWorld

_HERE = Path(__file__).parent

TOOLS = [
    {
        "name": "verify_identity",
        "description": "Verify the right party by matching ONE factor (dob | zip | last4). Must pass before any disclosure.",
        "parameters": {
            "answer": {
                "type": "str",
                "values": null
            },
            "factor": {
                "type": "str",
                "values": [
                    "dob",
                    "zip",
                    "last4"
                ]
            }
        }
    },
    {
        "name": "leave_compliant_message",
        "description": "Wrong party / unavailable: leave a message that does NOT disclose the debt, then end.",
        "parameters": {}
    },
    {
        "name": "schedule_callback",
        "description": "Schedule a callback within allowed contact hours, then end.",
        "parameters": {
            "when": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "get_account_summary",
        "description": "Return creditor and current balance. Only after verification.",
        "parameters": {}
    },
    {
        "name": "to_negotiation",
        "description": "Move to resolving the balance once creditor and balance have been stated.",
        "parameters": {}
    },
    {
        "name": "get_plan_options",
        "description": "Return allowable payment-plan options for the balance.",
        "parameters": {
            "balance": {
                "type": "float",
                "values": null
            }
        }
    },
    {
        "name": "log_dispute",
        "description": "Debtor disputes the debt: pause collection, trigger validation notice, end.",
        "parameters": {
            "reason": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "to_payment",
        "description": "Debtor agrees to pay in full or selects a plan.",
        "parameters": {
            "plan_id": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "send_payment_link",
        "description": "Text a secure hosted payment page. Never captures card/bank details in-conversation.",
        "parameters": {
            "channel": {
                "type": "str",
                "values": [
                    "sms"
                ]
            }
        }
    },
    {
        "name": "transfer_to_payment_ivr",
        "description": "Warm-transfer to the secure automated payment line.",
        "parameters": {}
    },
    {
        "name": "record_promise_to_pay",
        "description": "Record a promise-to-pay and end with the confirmation.",
        "parameters": {
            "amount": {
                "type": "float",
                "values": null
            },
            "date": {
                "type": "str",
                "values": null
            },
            "method": {
                "type": "str",
                "values": [
                    "link",
                    "ivr",
                    "plan"
                ]
            }
        }
    },
    {
        "name": "request_cease_communication",
        "description": "Caller asks to stop being contacted ('stop calling me', 'do not call'). Honor immediately.",
        "parameters": {}
    },
    {
        "name": "report_attorney_representation",
        "description": "Caller says they have or want a lawyer / are represented by an attorney.",
        "parameters": {
            "attorney_info": {
                "type": "str",
                "values": null
            }
        }
    },
    {
        "name": "escalate_to_human",
        "description": "Caller demands a human/supervisor, or is abusive/threatening. Warm-transfer with a summary.",
        "parameters": {
            "reason": {
                "type": "str",
                "values": null
            }
        }
    }
]


class World(GeneratedWorld):
    name = 'debt_collection'
    tools = TOOLS
    handlers = {
        name: (_HERE / "handlers" / f"{name}.py").read_text(encoding="utf-8")
        for name in []
    }


def load(database=None):
    """This world, restored from the snapshot beside this file.

    Through `restore` rather than by opening a database directly, because not every world has
    one: an agent whose state lives in services and files keeps its records in the snapshot, and
    naming a SQLite file would hand back an empty world instead of this one.
    """
    from fi.alk.harness.world.snapshot import restore

    return restore(_HERE, into=database) if database else restore(_HERE)
