def setup(world):
    """This scenario runs on the base world unchanged."""
