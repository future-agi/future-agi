def ready(world):
    summary_rows = world.state().get("account_summary", [])
    if not summary_rows or summary_rows[0].get("balance") != 842.17:
        return "account_summary missing or balance not 842.17"
    return None