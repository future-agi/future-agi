CREATE TABLE IF NOT EXISTS harness_seed_sentinel (id text PRIMARY KEY);
INSERT INTO harness_seed_sentinel(id) VALUES ('ready') ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS _alk_tool_trace (id bigserial PRIMARY KEY, name text NOT NULL, arguments jsonb NOT NULL, result jsonb, ok boolean NOT NULL, error text, at double precision NOT NULL);
CREATE TABLE IF NOT EXISTS "account_summary" ("account_id" text PRIMARY KEY, "debtor_name" text NOT NULL, "balance" double precision NOT NULL, "creditor" text NOT NULL, "days_past_due" bigint NOT NULL, "min_payment" double precision NOT NULL);
CREATE TABLE IF NOT EXISTS "plan_options" ("plan_id" text PRIMARY KEY, "months" bigint NOT NULL, "monthly" double precision NOT NULL, "min_down" double precision NOT NULL);
