from agent import PaymentAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = PaymentAgent()
    return settled(instance.transfer_to_payment_ivr(db.state, **args))
