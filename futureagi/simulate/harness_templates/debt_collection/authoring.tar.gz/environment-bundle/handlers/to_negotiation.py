from agent import DisclosureAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = DisclosureAgent()
    return settled(instance.to_negotiation(db.state, **args))
