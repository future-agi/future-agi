from agent import BaseCollections
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = BaseCollections()
    return settled(instance.request_cease_communication(db.state, **args))
