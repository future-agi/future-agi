from agent import RightPartyAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = RightPartyAgent()
    return settled(instance.schedule_callback(db.state, **args))
