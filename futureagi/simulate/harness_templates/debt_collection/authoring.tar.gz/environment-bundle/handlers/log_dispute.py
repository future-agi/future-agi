from agent import NegotiationAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = NegotiationAgent()
    return settled(instance.log_dispute(db.state, **args))
