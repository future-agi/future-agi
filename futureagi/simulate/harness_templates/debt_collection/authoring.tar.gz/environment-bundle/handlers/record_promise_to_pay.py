from agent import PaymentAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = PaymentAgent()
    return settled(instance.record_promise_to_pay(db.state, **args))
