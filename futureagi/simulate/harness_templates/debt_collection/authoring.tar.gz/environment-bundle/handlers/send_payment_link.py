from agent import PaymentAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = PaymentAgent()
    return settled(instance.send_payment_link(db.state, **args))
