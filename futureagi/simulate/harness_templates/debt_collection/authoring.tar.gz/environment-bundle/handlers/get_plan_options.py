from agent import NegotiationAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = NegotiationAgent()
    return settled(instance.get_plan_options(db.state, **args))
