from agent import RightPartyAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = RightPartyAgent()
    return settled(instance.leave_compliant_message(db.state, **args))
