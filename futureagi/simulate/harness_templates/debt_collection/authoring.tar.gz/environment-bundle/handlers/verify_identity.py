from agent import RightPartyAgent
from fi.alk.harness.world.runtime import settled

def handle(args, db):
    instance = RightPartyAgent()
    return settled(instance.verify_identity(db.state, **args))
